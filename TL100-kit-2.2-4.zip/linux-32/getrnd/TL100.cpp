#include "stdafx.h"

/*
 * TL100.cpp
 * ver. 2.1
 *
 */

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Copyright (C) 2013-2015 TectroLabs, http://tectrolabs.com

THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

This class is used as a software API for interacting with the hardware random data generator device TL100 for the purpose of
downloading random bytes. The TL100 device should be connected to an available USB port and a proper USB driver should be 
installed. 

Please refer to README.doc document for USB driver installation instructions and for OS compatibility information.

This class uses the FTDI D2XX driver for interacting with the TL100 device.

This class may only be used in conjunction with the TL100 device.

This utility will require 'sudo' permissions when running in a Linux environment.

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/


#include "TL100.h"

// Random bit stream data are downloaded in chunks. This is the maximum size of one chunk.
// Not recommended to change this value.
#define MAX_RECEIVE_CHUNK_BYTES 20000

/**
 * Constructor
 *
 */
TL100::TL100() {
	initialize();
}

/**
 * Set data generator mode for TL100 device to 'Raw Bytes'
 *
 */
void TL100::setRawMode() {
	genMode = 'r';
}

/**
 * Set data generator mode for TL100 device to 'Low Bias'
 *
 */
void TL100::setLowBiasMode() {
	genMode = 'x';
}

/**
 * Set data generator mode for TL100 device to 'SHA160'
 *
 */
void TL100::setSHA1Mode() {
	genMode = '1';
}

/**
 * Set data generator mode for TL100 device to 'SHA256'.
 * This is also default mode.
 *
 */
void TL100::setSHA2Mode() {
	genMode = '2';
}

/**
 * Set data generator mode for TL100 device to 'SHA512'
 *
 */
void TL100::setSHA512Mode() {
	genMode = '3';
}

/**
 * Set data generator mode for TL100 device to 'HmacSHA160'
 *
 */
void TL100::setHMACMode() {
	genMode = 'h';
}

/**
 * Retrieve a complete list of TL100 and other FTDI devices currently plugged into USB ports
 *
 * @param DeviceInfoList* devInfoList - pointer to the structure for holding TL100 and FTDI USB devices
 * @return int value 0 if processed - successfully, otherwise FTDI driver status code
 *
 */
int TL100::listDevices(DeviceInfoList *devInfoList) {
	TL100 tl;
	DWORD numDevs;
	DeviceModel dm;
	DeviceVersion dv;
	DeviceSerialNumber sn;
	FT_DEVICE_LIST_INFO_NODE *devInfo;
	memset( devInfoList, 0, sizeof( DeviceInfoList ) );

	ftStatus = FT_CreateDeviceInfoList(&numDevs);
	if (ftStatus != FT_OK) {
		return ftStatus;
	}

	if (numDevs > 0) {
		devInfo = (FT_DEVICE_LIST_INFO_NODE*)malloc(sizeof(FT_DEVICE_LIST_INFO_NODE)*numDevs);
		if (devInfo == NULL) {
			return -1;
		}
		ftStatus = FT_GetDeviceInfoList(devInfo, &numDevs); 
		if (ftStatus != FT_OK) {
			free(devInfo);
			return ftStatus;
		}
		for (DWORD i = 0; i < numDevs && i < sizeof(devInfoList->devInfoList); i++) {
			devInfoList->numDevs++;
			devInfoList->devInfoList[i].devNum = i;
			devInfoList->devInfoList[i].usbID = devInfo[i].ID;
			devInfoList->devInfoList[i].usbLocId = devInfo[i].LocId;
			strcpy(devInfoList->devInfoList[i].usbConfigID, devInfo[i].SerialNumber);

			if (devInfo[i].Flags != 1) {

#ifdef _WIN32
				// This section will only work for Windows OS
				FT_HANDLE ftHandle1;
				LONG lComPortNumber;
				ftStatus = FT_OpenEx(devInfo[i].SerialNumber, FT_OPEN_BY_SERIAL_NUMBER, &ftHandle1);
				if (ftStatus == FT_OK) {
					ftStatus = FT_GetComPortNumber(ftHandle1, &lComPortNumber);
					if (ftStatus == FT_OK) {
						devInfoList->devInfoList[i].comPortNumber = (int)lComPortNumber;
					}
					FT_Close(ftHandle1);
				}
#endif

				ftStatus = tl.open(i);
				if (ftStatus != FT_OK) {
					tl.close();
					continue;
				}

				ftStatus = tl.getDeviceModel(&dm);
				if (ftStatus != FT_OK) {
					tl.close();
					continue;
				}
				strcpy(devInfoList->devInfoList[i].deviceModel, dm.value);

				ftStatus = tl.getDeviceVersion(&dv);
				if (ftStatus != FT_OK) {
					tl.close();
					continue;
				}
				strcpy(devInfoList->devInfoList[i].deviceVersion, dv.value);

				ftStatus = tl.getDeviceSerialNumber(&sn);
				if (ftStatus != FT_OK) {
					tl.close();
					continue;
				}
				strcpy(devInfoList->devInfoList[i].deviceSerialNumber, sn.value);

				FT_PROGRAM_DATA ftData;
				ftStatus = tl.readEEPROM(&ftData);
				if (ftStatus != FT_OK) {
					tl.close();
					continue;
				}
				devInfoList->devInfoList[i].prodID = ftData.ProductId;

				tl.close();
			}
		}
		free(devInfo);
	}
	return FT_OK;
}

/**
 * Save FTDI device serial number
 * @param int deviceNum - device number (0 - for the first device)
 */
void TL100::saveFTDISerialNumber(int deviceNum) {
	FT_STATUS ftStatus; 
	FT_HANDLE ftHandleTemp; 
	DWORD numDevs; 
	DWORD Flags; 
	DWORD ID; 
	DWORD Type; 
	DWORD LocId; 
	char SerialNumber[16]; 
	char Description[64]; 
 
	ftStatus = FT_CreateDeviceInfoList(&numDevs); 
	if (ftStatus == FT_OK && numDevs > 0) { 
		ftStatus = FT_GetDeviceInfoDetail(deviceNum, &Flags, &Type, &ID, &LocId, SerialNumber, Description, &ftHandleTemp); 
		if (ftStatus == FT_OK) { 
			strcpy(curFTDISerialNumber,SerialNumber); 
		} 
	}	 
}

/**
 * Destructor
 *
 */
TL100::~TL100() {
	close();
}

/**
 * Close device if open
 *
 * @return int - 0 when processed successfully, otherwise FTDI driver status code
 */
int TL100::close() {
	if (deviceOpen == true) {
		deviceOpen = false;
		ftStatus = FT_Close(ftHandle);
	}
	return FT_OK;
}

/**
 * Reset statistics for the TL100 device
 *
 */
void TL100::resetDeviceStatistics() {
	time(&ds.beginTime);	// Start performance timer
	ds.downloadSpeedKBsec = 0;
	ds.numGenBytes = 0;
	ds.totalRetries = 0;
	ds.endTime = 0;
	ds.totalTime = 0;
}

/**
 * Generate and retrieve device statistics
 *
 */
DeviceStatistics* TL100::generateDeviceStatistics() {
	time (&ds.endTime);	// Stop performance timer
	// Calculate performance
	ds.totalTime = ds.endTime - ds.beginTime;
	if (ds.totalTime == 0) {
		ds.totalTime = 1;
	}
	ds.downloadSpeedKBsec =  (int)(ds.numGenBytes / (int64_t)1024 / (int64_t)ds.totalTime);
	return &ds;
}

/**
 * Set the flag that indicates if all post processing logic 
 * should run on the TL100 device only. Set this flag to true to prevent
 * consuming additional CPU resources on host computer.
 *
 * @param bool fdpp - true to run post processing logic only on the TL100 device
 */
void TL100::setDevicePostProcessing(bool fdpp) {
	isPostProcessingOnDevice = fdpp;
}

/**
 * Initialize this software deriver instance
 *
 */
void TL100::initialize() {
	initializePlatform();
	clearLastErrMsg();
	initDeviceReOpenCnt();
	deviceOpen = false;
	isPostProcessingOnDevice = false;
	ftStatus = FT_OK;
	baudRate = 3000000;				// Currently set at 3 Mbps. Do not change this value! 
	receiveTimeOutMlSecs = 1000;	// 1 second receive time out
	sendTimeOutMlSecs = 60;			// 60 milliseconds send time out
	setSHA2Mode();					// Set default generation mode to SHA2
	maxRetriesPerChunk = 15;		// Retry count used for downloading one chunk of bit stream before throwing an error.
	resetDeviceStatistics();
	sha256.initializeSerialNumber((uint32_t)ds.beginTime);
	statusByte = 0;
	apt.initialize(&statusByte);
	rct.initialize(&statusByte);
	enableAutoRecoverMode();		// Enable auto recover mode to re-establish the lost connection to TL100 device
}

/**
 * Initialize the number of times left to re-opeening the device before setting the failure condition
 *
 */
void TL100::initDeviceReOpenCnt() {
	openDevLeftCount = 10;
	sleepReOpenMlsecs = 6000;
}

/**
 * Clear the last error message
 *
 */
void TL100::clearLastErrMsg() {
	setLastErrMsg("");
}

/**
 *  Enable auto recover mode to re-establish the lost connection to TL100 device
 *
 */
void TL100::enableAutoRecoverMode() {
	autoRecoverMode = true;
}

/**
 *  Disable auto recover mode 
 *
 */
void TL100::disableAutoRecoverMode() {
	autoRecoverMode = false;
}

/**
 * Initialize platform
 *
 */
void TL100::initializePlatform() {
#ifndef _WIN32
	// Set proper PID For Linux and MAC OSX
	// Product ID 0x77d2 is reserved and should only be used with TectroLabs Hardware RNG devices
	FT_SetVIDPID(0x0403, 0x77d2);
#endif /* non _WIN32 */
}

/**
 * Open FTDI USB specific device.
 *
 * @param int deviceNum - device number (0 - for the first device)
 * @return int 0 - when open successfully or FTDI driver status error
 */
int TL100::open(int deviceNum) {
	close();

	// Open FTDI USB device
	ftStatus = FT_Open(deviceNum, &ftHandle);
	if(ftStatus != FT_OK) {
		setLastErrMsg("Could not open FTDI device");
		return ftStatus;
	}
	deviceOpen = true;
	this->deviceNum = deviceNum;

	// Set byte format
	// Set 8 data bits, 1 stop bit and no parity
	ftStatus = FT_SetDataCharacteristics(ftHandle, FT_BITS_8, FT_STOP_BITS_1, FT_PARITY_NONE);
	if(ftStatus != FT_OK) {
		setLastErrMsg("Could not set FTDI device data characteristics");
		return ftStatus;
	}

	// Set flow control
	ftStatus = FT_SetFlowControl(ftHandle, FT_FLOW_NONE, 0x11, 0x13);
	if(ftStatus != FT_OK) {
		setLastErrMsg("Could not set FTDI device flow control");
		return ftStatus;
	}

	// Set baud rate
	ftStatus = FT_SetBaudRate(ftHandle, baudRate);
	if(ftStatus != FT_OK) {
		setLastErrMsg("Could not set FTDI device baud rate");
		return ftStatus;
	}

	// Set device transmission timeout
	ftStatus = updateTransmissionTimeouts(receiveTimeOutMlSecs, sendTimeOutMlSecs);
	if(ftStatus != FT_OK) {
		return ftStatus;
	}

	// Save FTDI device serial number for re-establishing lost connections
	saveFTDISerialNumber(deviceNum);

	return FT_OK;
}

/**
 * Re-open FTDI device based on the last known USB serial number 
 *
 * @return int 0 - when open successfully
 */
int TL100::openLastUsedDevice() {
	close();
	clearLastErrMsg();
	initializePlatform();

	// Look for a FTDI device with saved USB serial number
	FT_STATUS ftStatus; 
	FT_HANDLE ftHandleTemp; 
	DWORD numDevs; 
	DWORD Flags; 
	DWORD ID; 
	DWORD Type; 
	DWORD LocId; 
	char SerialNumber[16]; 
	char Description[64]; 
 
	ftStatus = FT_CreateDeviceInfoList(&numDevs); 
	if (ftStatus == FT_OK && numDevs > 0) { 
		for (DWORD devNum = 0; devNum < numDevs; devNum++) {
			ftStatus = FT_GetDeviceInfoDetail(devNum, &Flags, &Type, &ID, &LocId, SerialNumber, Description, &ftHandleTemp); 
			if (ftStatus == FT_OK) { 
				if (strcmp(curFTDISerialNumber, SerialNumber) == 0) {
					return open(devNum);
				}
			} else {
				return -1;
			}
		}
	} else {
		return -1;
	}
	return -1;
}


/**
 * Update transmission timeout values for active connection
 *
 * @param ULONG rcvto - receive timeout value in milliseconds
 * @param ULONG sendto - send timeout value in milliseconds
 * @return int 0 - when open successfully or FTDI driver status error
 */
int TL100::updateTransmissionTimeouts(ULONG rcvto, ULONG sendto) {
	ftStatus = FT_SetTimeouts(ftHandle, rcvto, sendto);
	if(ftStatus != FT_OK) {
		setLastErrMsg("Could not set FTDI device timeout values");
	}
	return ftStatus;
}


/**
 * Retrieve TL100 device serial number. This call will fail when there is no TL100 device 
 * currently connected or when the device is already in use.
 *
 * @param DeviceSerialNumber* serialNumber - pointer to a structure for holding TL100 device S/N
 * @return int - 0 when serial number retrieved successfully
 *
 */
int TL100::getDeviceSerialNumber(DeviceSerialNumber *serialNumber) {
	if (deviceOpen == false) {
		setLastErrMsg("Device not open");
		return -1;
	}

	int resp = processOneByteCmd((uint8_t *)serialNumber->value, sizeof(DeviceSerialNumber) - 1, 's');
	// Replace status byte with \0 for ASCIIZ
	serialNumber->value[sizeof(DeviceSerialNumber)-1] = '\0';
	if (resp != FT_OK) {
		setLastErrMsg("Could not retrieve device serial number");
	}
	return resp;
}

/**
 * Retrieve TL100 device version. This call will fail when there is no TL100 device 
 * currently connected or when the device is already in use.
 *
 * @param DeviceVersion* version - pointer to a structure for holding TL100 device version
 * @return int - 0 when version retrieved successfully
 *
 */
int TL100::getDeviceVersion(DeviceVersion *version) {
	if (deviceOpen == false) {
		setLastErrMsg("Device not open");
		return -1;
	}

	int resp = processOneByteCmd((uint8_t *)version->value, sizeof(DeviceVersion) - 1, 'v');
	// Replace status byte with \0 for ASCIIZ
	version->value[sizeof(DeviceVersion)-1] = '\0';
	if (resp != FT_OK) {
		setLastErrMsg("Could not retrieve device version");
	}
	return resp;
}

/**
 * Retrieve TL100 device model number. This call will fail when there is no TL100 device 
 * currently connected or when the device is already in use.
 *
 * @param DeviceModel* model - pointer to a structure for holding TL100 device model number
 * @return int 0 - when model retrieved successfully
 *
 */
int TL100::getDeviceModel(DeviceModel *model) {
	if (deviceOpen == false) {
		setLastErrMsg("Device not open");
		return -1;
	}

	int resp = processOneByteCmd((uint8_t *)model->value, sizeof(DeviceModel) - 1, 'm');
	// Replace status byte with \0 for ASCIIZ
	model->value[sizeof(DeviceModel)-1] = '\0';
	if (resp != FT_OK) {
		setLastErrMsg("Could not retrieve device model");
	}
	return resp;
}

/**
 * Retrieve random bytes from the TL100 device
 *
 * @param uint8_t* dest - pointer to an array for storing the random bytes received.
 *			The array should be able to hold [numGenBytes + 1] elements
 * @param uint32_t numGenBytes - number of random bytes to retrieve
 * @return int - 0 when bytes retrieved successfully or error code
 */
int TL100::getBytes(uint8_t *dest, uint32_t numGenBytes) {

	int retCode = -1;

	if (deviceOpen == false) {
		setLastErrMsg("Device could not be used");
		return -1;
	}

	do {
		switch(genMode) {
			case '2':
				if (isPostProcessingOnDevice == false) {
					retCode = hostHashing(dest, numGenBytes);
					break;
				}
			default:
				retCode = getDeviceBytes(dest, numGenBytes, genMode);
		}
		if (retCode == 0) {
			initDeviceReOpenCnt();
		} else {
			sleepMlSecs(sleepReOpenMlsecs);
			retCode = openLastUsedDevice();
		}
	} while (retCode != 0 && --openDevLeftCount > 0 && autoRecoverMode == true);	
	return retCode;
}


/**
 * Sleep specified amount of milliseconds
 *
 * @param int mlsecs - milliseconds
 */
void TL100::sleepMlSecs(int mlsecs) {
	#ifdef _WIN32
		Sleep(mlsecs);
	#else
		usleep(mlsecs * 1000);
	#endif
}

/**
 * Retrieve random bytes from the TL100 device and apply Sha256 post processing logic
 *
 * @param uint8_t* dest - pointer to an array for storing the random bytes received.
 *			The array should be able to hold [numGenBytes + 1] elements
 * @param uint32_t numGenBytes - number of random bytes to retrieve
 * @return int - 0 when bytes retrieved successfully or error code
 */
int TL100::hostHashing(uint8_t dest[], uint32_t numGenBytes) {
	int res;
	uint32_t numProcessedBytes = 0;

	ShaBase *hash = getHashImpl();
	if (hash == NULL) {
		setLastErrMsg("Error identifying host hashing algorithm");
		return -1;
	}

	// Restart the tests
	apt.restart();
	rct.restart();

	uint16_t hashBlockSizeWords = hash->getOutputNumWords();
	uint16_t wordSizeBytes = hash->getWordSizeBytes();
	uint16_t hashBlockSizeBytes = hashBlockSizeWords * wordSizeBytes;

	// Calculate how many hash blocks we need
	uint32_t hashNumBlocks = numGenBytes / hashBlockSizeBytes;
	if (numGenBytes % hashBlockSizeBytes > 0) {
		hashNumBlocks++;
	}

	// Allocate required number of low bias random bytes
	uint16_t inputNumWords = hash->getMinInputNumWords();
	uint16_t inputNumBytes = inputNumWords * wordSizeBytes;
	uint32_t totalInputRndBytes = hashNumBlocks * inputNumBytes;
	if (mb.initialize(totalInputRndBytes + 1) != 0) { // Add one more for status byte
		setLastErrMsg("Could not allocate memory for low bias random bytes");
		return -1;
	}
	// Allocate memory for hash results
	if (hmb.initialize(hashBlockSizeBytes) != 0) {
		setLastErrMsg("Could not allocate memory for hash data output");
		return -1;
	}
	// Allocate memory for hash input 
	if (imb.initialize(inputNumBytes + wordSizeBytes) != 0) { // Add one more word for block serial number
		setLastErrMsg("Could not allocate memory for hash data input");
		return -1;
	}

	// Retrieve low bias random bytes for hashing
	res = getDeviceBytes(mb.getAddress(), totalInputRndBytes, 'x');
	if (res != 0) {
		setLastErrMsg("Could not retrieve low bias random bytes for hashing");
		return res;
	}

	uint8_t *hashSrc = mb.getAddress();
	uint32_t genBytesRemain = numGenBytes;
	uint8_t *hashDest = hmb.getAddress();
	uint8_t *origDest = dest;
	// Hash low bias random bytes in hash blocks
	for (uint32_t bn = 0; bn < hashNumBlocks; bn++) {

		// Prepare hash input block
		uint8_t *hashSrcBlock = imb.getAddress();
		for (uint16_t h = 0; h < inputNumBytes; h++) {
			hashSrcBlock[h] = hashSrc[bn*inputNumBytes + h];
		}
		// Generate block serial number
		hash->stampSerialNumber(imb.getAddress());
		// Hash one block
		res = hash->generateHash(imb.getAddress(), imb.getAllocatedSize() / wordSizeBytes, hmb.getAddress());
		if (res != 0) {
			setLastErrMsg("Could not generate hash for a data block");
			return res;
		}
		// Store hash results
		for (int16_t i = hashBlockSizeBytes - 1; i >= 0; i--) {
			if (genBytesRemain-- <= 0) {
				return statusByte;
			}
			if (++numProcessedBytes % MAX_RECEIVE_CHUNK_BYTES == 0) {
				// Restart these tests after each data chunk 
				apt.restart();
				rct.restart();

			}
			apt.sample(hashDest[i]);
			rct.sample(hashDest[i]);
			*origDest++ = hashDest[i];
		}
	}

	return statusByte;
}

/**
 * A method to create a specific Hashing algorithm instance
 *
 * @return ShaBase* - a pointer to specific HASH implementation or NULL
 */
ShaBase *TL100::getHashImpl() {
	switch(genMode) {
		case '2':
			return &sha256;
			break;
		default:
			return 0;
	}
}

/**
 * A method to set the last error message
 *
 * @param msg - a pointer to specific ASCIZ error message
 */
void TL100::setLastErrMsg(const char *msg) {
	lastErrMsg.initialize(strlen(msg) + 1);
	strcpy((char*)lastErrMsg.getAddress(), msg);
}

/**
 * A method to retrieve the last error message
 *
 * @return char* - a pointer to the last ASCIZ error message
 */
char *TL100::getLastErrMsg() {
	return (char*)lastErrMsg.getAddress();
}

/**
 * Retrieve random bytes from the TL100 device using specific generator mode
 *
 * @param uint8_t* dest - pointer to an array for storing the random bytes received.
 *			The array should be able to hold [numGenBytes + 1] elements
 * @param uint32_t numGenBytes - number of random bytes to retrieve
 * @param char genMode - generator mode
 * @return int - 0 when bytes retrieved successfully or error code
 */
int TL100::getDeviceBytes(uint8_t *dest, uint32_t numGenBytes, char genMode) {

	// Calculate the number of complete random byte chunks to download
	int64_t numCompleteChunks = numGenBytes / MAX_RECEIVE_CHUNK_BYTES;

	// Calculate the number of bytes in the last incomplete chunk
	uint16_t chunkRemaindBytes = numGenBytes % MAX_RECEIVE_CHUNK_BYTES;

	// Start processing each chunk
	int64_t chunkNum;
	for (chunkNum = 0; chunkNum < numCompleteChunks; chunkNum++) {
		int resp = getBytes(dest, MAX_RECEIVE_CHUNK_BYTES, genMode);
		if (resp != FT_OK) {
			return resp;
		}
		dest += MAX_RECEIVE_CHUNK_BYTES;
	}

	if (chunkRemaindBytes > 0) {
		//Processing incomplete chunk
		int resp = getBytes(dest, chunkRemaindBytes, genMode);
		if (resp != FT_OK) {
			return resp;
		}
	}
	return FT_OK;
}

/**
 * Retrieve random bytes using specific command
 *
 * @param uint8_t* dest - pointer to an array for storing the random bytes received.
 *			The array should be able to hold [byteCnt + 1] elements
 * @param uint16_t byteCnt - number of random bytes to retrieve
 * @param char cmd - TL100 device API command
 * @return int - 0 when bytes retrieved successfully or error code
 */
int TL100::getBytes(uint8_t *dest, uint16_t byteCnt, char cmd) {
	uint16_t tryCount = maxRetriesPerChunk;
	while (tryCount-- > 0) {
		sendRequest(byteCnt, cmd);
		uint16_t expctdByteCnt = byteCnt + 1;
		uint16_t actualBytesReceived = getDeviceBytes(dest, expctdByteCnt);
		if (actualBytesReceived == expctdByteCnt) {
			return FT_OK;
		}
		ds.totalRetries++;
	}
	setLastErrMsg("Could not retrieve expected bytes from TL100 device");
	return -1;
}

/**
 * Process one byte command and retrieve the response as bytes
 *
 * @param uint8_t* dest - pointer to an array for storing the response.
 *			The array should be able to hold [byteCnt + status byte] elements
 * @param uint16_t byteCnt - number of response bytes to retrieve
 * @param char cmd - TL100 device API command
 * @return int - 0 when bytes retrieved successfully or error code
 */
int TL100::processOneByteCmd(uint8_t *dest, uint16_t byteCnt, char cmd) {
	uint16_t tryCount = maxRetriesPerChunk;
	while (tryCount-- > 0) {
		sendRequest(cmd);
		uint16_t expctdByteCnt = byteCnt + 1;
		uint16_t actualBytesReceived = getDeviceBytes(dest, expctdByteCnt);
		if (actualBytesReceived == expctdByteCnt) {
			// Test the status byte
			if (dest[byteCnt] == 0) {
				return FT_OK;
			} else {
				// TL100 device has failed
				return dest[byteCnt];
			}
		}
		ds.totalRetries++;
	}
	setLastErrMsg("Could not retrieve expected bytes from TL100 device");
	return -1;
}


/**
 * Send download request command to the TL100 device
 *
 * @param uint16_t byteCnt - number of bytes to retrieve
 * @param char cmd - TL100 device API command
 * @return int - 0 when bytes retrieved successfully or error code
 */
int TL100::sendRequest(uint16_t byteCnt, char cmd) {
	DWORD dwBytesWritten = 0;
	char sendBuff[3];

	// Send command first 
	sendBuff[0] = cmd;

	// Calculate and send the requested amount of bytes as an uint16_t
	uint8_t lowByteCount  = byteCnt & 0x00ff;
	uint8_t highByteCount = byteCnt >> 8;

	// First send the low byte
	sendBuff[1] = lowByteCount;

	// Then send the high byte
	sendBuff[2] = highByteCount;

	// Send the three bytes
	ftStatus = FT_Write(ftHandle, (LPVOID)sendBuff, 3, &dwBytesWritten);

	// Check for errors
	if (ftStatus != FT_OK) {
		return ftStatus;
	}
	if (dwBytesWritten != 3) {
		return -1;
	}

	return FT_OK;
}

/**
 * Send command to the TL100 device
 *
 * @param char cmd - TL100 device API command
 */
int TL100::sendRequest(char cmd) {
	DWORD dwBytesWritten = 0;

	// Send command byte
	ftStatus = FT_Write(ftHandle, (LPVOID)&cmd, 1, &dwBytesWritten);

	// Check for errors
	if (ftStatus != FT_OK) {
		return ftStatus;
	}
	if (dwBytesWritten != 1) {
		return -1;
	}
	return FT_OK;
}

/**
 * Retrieve expected amount of bytes from the TL100 device
 *
 * @param uint8_t* dest - pointer to an array for storing the random bytes received.
 *			The array should be able to hold [numGenBytes + 1] elements
 * @param uint16_t byteCnt - number of random bytes to retrieve
 * @return int - 0 when bytes retrieved successfully or error code
 */
uint16_t TL100::getDeviceBytes(uint8_t *dest, uint16_t byteCnt) {
	DWORD dwBytesRead = 0;

	// Receive bytes
	ftStatus = FT_Read(ftHandle, (LPVOID)dest, byteCnt, &dwBytesRead);
	if(ftStatus != FT_OK) {
		return -100;
	}

	// Check to see if all of the expected bytes received
	if ((int16_t)dwBytesRead == byteCnt) {
		// Check TRNG status
		if (dest[byteCnt-1] != 0) {
			// TRNG failed with an error code
			fprintf(stderr, "\nTL100 failed with error code: %d\n", (int)dest[byteCnt-1]);
			return -(dest[byteCnt-1]);
		}
		ds.numGenBytes += byteCnt;
		return byteCnt;
	} else {
		return -100;
	}
}


/**
 * Receive expected amount of bytes from the TL100 device
 *
 * @param uint8_t* dest - pointer to an array for storing the random bytes received.
 *			The array should be able to hold [byteCnt] elements
 * @param uint16_t byteCnt - number of bytes to retrieve from the TL100 device
 * @return int - number of bytes retrieved successfully
 *              -1 when there is a communication error
 *              -2 when the expected bytes were not received within expected time
 */
int TL100::receiveBytes(uint8_t *dest, uint16_t byteCnt) {
	DWORD dwBytesRead = 0;

	// Receive bytes
	ftStatus = FT_Read(ftHandle, (LPVOID)dest, byteCnt, &dwBytesRead);
	if(ftStatus != FT_OK) {
		return -1;
	}

	// Check to see if all of the expected bytes received
	if ((int16_t)dwBytesRead == byteCnt) {
		ds.numGenBytes += byteCnt;
		return byteCnt;
	} else {
		return -2;
	}
}

/**
 * Read EEPROM content
 * @return int - 0 when successful
 */
int TL100::readEEPROM(FT_PROGRAM_DATA *ftData) {
	if (deviceOpen == false) {
		setLastErrMsg("Device not open to read from EEPROM");
		return -1;
	}

	ftData->Signature1 = 0x00000000;
	ftData->Signature2 = 0xffffffff;
	ftData->Manufacturer = ManufacturerBuf;
	ftData->ManufacturerId = ManufacturerIdBuf;
	ftData->Description = DescriptionBuf;
	ftData->SerialNumber = SerialNumberBuf;

	ftStatus = FT_EE_Read(ftHandle, ftData);
	return ftStatus;
}

/**
 * Write EEPROM content
 * @return int - 0 when successful
 */
int TL100::writeEEPROM(FT_PROGRAM_DATA *ftData) {
	if (deviceOpen == false) {
		setLastErrMsg("Device not open to write to EEPROM");
		return -1;
	}

	ftData->Signature1 = 0x00000000;
	ftData->Signature2 = 0xffffffff;

	ftStatus = FT_EE_Program(ftHandle, ftData);
	return ftStatus;
}
