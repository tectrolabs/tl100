#!/bin/sh

#
# This script will load tlrandom module. It will create a new nod
# if it doesn't exist or if the major number changed. 
#

devmode="644"		# change for different permissions
module="tlrandom"	# should not change
device="tlrandom"	# can be changed to a different name
devicepath="/dev/$device"
neednewnod="yes"

/sbin/insmod ./$module.ko $* || exit 1
major="$(awk "\$2==\"$module\" {print \$1}" /proc/devices)"
echo "Module $module loaded with major number $major"

if [ -e $devicepath ]; then
oldmajor="$(ls -al $devicepath | cut -d ' ' -f 5 | cut -d ',' -f 1)"
if [ "$oldmajor" -eq "$major" ]; then
neednewnod="no"
fi
fi

#only make a new nod when the new major number is different
if [ "$neednewnod" = "yes" ]; then
rm -f $devicepath	# remove the stale nod
mknod $devicepath c $major 0	# make a new nod
echo "new nod $devicepath created"
fi

chmod $devmode $devicepath 
echo "Using device $devicepath with $devmode permissions"
