/*
 * SHA256.h
 * ver. 1.6.4
 *
 */

/*********************************************************************************************

Copyright � 2013 TectroLabs, http://tectrolabs.com

THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

This class implements SHA-256 hashing algorithm based on 'FIPS PUB 180-4' publication 
for Secure Hash Standard (SHS) 2012 by National Institute of Standards and Technology (NIST).

Implementation exceptions: 
This SHA-2 implementation is stateless and operates only on 32 bit words.
It should only be used with the TL100 device as a bias remover. 

This class may only be used in conjunction with the TL100 device.

*********************************************************************************************/


#ifndef SHA256_H_
#define SHA256_H_

#include <stdint.h>
#include "ShaBase.h"


class SHA256 : public ShaBase {

	public:
		int generateHash(uint32_t *src, int16_t len, uint32_t *dst);
		int generateHash(void *src, int16_t len, void *dst);
		uint16_t getMinInputNumWords();
		uint16_t getOutputNumWords();
		uint16_t getWordSizeBytes();
		void stampSerialNumber(void *inputBlock);
		void initializeSerialNumber(uint32_t initValue);


	private:
		uint32_t ch(uint32_t *x, uint32_t *y, uint32_t *z);
		uint32_t maj(uint32_t *x, uint32_t *y, uint32_t *z);
		uint32_t sum0(uint32_t *x);
		uint32_t sum1(uint32_t *x);
		uint32_t sigma0(uint32_t *x);
		uint32_t sigma1(uint32_t *x);
		void hashCurrentBlock();
		void initialize();
		uint32_t a,b,c,d,e,f,g,h;
		uint32_t h0,h1,h2,h3,h4,h5,h6,h7;
		uint32_t tmp1, tmp2;
		uint32_t w[64];
		static const uint32_t k[64];
		static const uint8_t maxDataBlockSizeWords;
		static const uint16_t minInputNumWords;
		static const uint16_t outputNumWords;
		uint32_t blockSerialNumber;

};

#endif /* SHA256_H_ */
