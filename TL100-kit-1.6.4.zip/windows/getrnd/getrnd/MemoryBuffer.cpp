#include "stdafx.h"
/*
 * MemoryBuffer.cpp
 * ver. 1.6.4
 *
 */

/*********************************************************************************************

Copyright � 2013 TectroLabs, http://tectrolabs.com

THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

This class may only be used in conjunction with the TL100 device.

*********************************************************************************************/


#include "MemoryBuffer.h"

/**
 * Constructor
 *
 */
MemoryBuffer::MemoryBuffer() {
	buff = 0;
	bytesAllocated = 0;
}


/**
 * Initialize (allocate) the requested amount of bytes. 
 * This method will do nothing if the required amount of bytes 
 * already allocated
 *
 * @param int bytes number of bytes to allocate
 * @return int 0 if memory successfully allocated
 *
 */
int MemoryBuffer::initialize(int bytes) {
	if (buff != 0 && bytesAllocated != bytes) {
		delete [] buff;
		buff = 0;
		bytesAllocated = 0;
	}

	if (buff == 0) {
		buff = new uint8_t[bytes];
		if (buff == 0) {
			return -1;
		} else {
			bytesAllocated = bytes;
			return 0;
		}
	}
	return 0;
}

/**
 * Return pointer to allocated byte arrays
 * @return uint8_t* pointer to allocated byte array
 *
 */
uint8_t *MemoryBuffer::getAddress() {
	return buff;
}

/**
 * Destructor.
 * Clean up and free the allocated byte array
 *
 */
MemoryBuffer::~MemoryBuffer() {
	if (buff != 0) {
		delete [] buff;
		buff = 0;
		bytesAllocated = 0;
	}

}

/**
 * Get the size of the byte arrays allocated
 *
 * @return int number of bytes currently allocated for array
 */
int MemoryBuffer::getAllocatedSize() {
	return bytesAllocated;
}
