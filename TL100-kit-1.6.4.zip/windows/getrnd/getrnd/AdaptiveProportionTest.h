/*
 * AdaptiveProportionTest.h
 * ver. 1.6.4
 *
 */ 

/*********************************************************************************************

Copyright � 2013 TectroLabs, http://tectrolabs.com

THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

This class implements Adaptive Proportion Test algorithm based on 'NIST SP 800-90B' publication 
section 6.5.1.2 by National Institute of Standards and Technology (NIST) 2012.

This class may only be used in conjunction with the TL100 device.

*********************************************************************************************/


#ifndef ADAPTIVEPROPORTIONTEST_H_
#define ADAPTIVEPROPORTIONTEST_H_

#include <stdint.h>


class AdaptiveProportionTest {
		private:
			uint16_t windoiwSize;
			uint16_t cutoffValue;
			uint16_t curRepetitions;
			uint16_t curSamples;
			uint8_t *statusByte;
			uint8_t signature;
			bool isInitialized;
			uint8_t firstSample;
			uint16_t cycleFailures;
			void restartCycle();
		public:
			void initialize(uint8_t *statusByte);
			void restart();
			void sample(uint8_t value);

		private:
			static const uint8_t numConsecFailThreshold;

	};

#endif /* ADAPTIVEPROPORTIONTEST_H_ */