#include "stdafx.h"
/*
 * TL100FILE.cpp
 * ver. 1.6.4
 *
 */

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Copyright � 2013 TectroLabs, http://tectrolabs.com

THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

This class is for interacting with the hardware random data generator device TL100 for the purpose of downloading
random bytes into a file. The TL100 device should be connected to an available USB port and a proper USB driver should be installed. 

Please refer to README.doc document for USB driver installation instructions and for OS compatibility information.

This class uses the FTDI D2XX driver for interacting with the TL100 device.

This class may only be used in conjunction with the TL100 device.

This utility will require 'sudo' permissions when running in a Linux environment.

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#include "TL100Util.h"

#define BUFF_SIZE_BYTES 100000

#ifdef _WIN32
  #define atoll(S) _atoi64(S)
#endif

/**
 * Initialize instance with command line arguments
 *
 * @param int argc
 * @param char** argv
 *
 */
void TL100Util::initialize(int argc, char **argv) {
	numGenBytes = -1;		// Unlimited number of bytes by default (continuous random data download)
	deviceNum = 0;			// First FTDI device by default
	isDataOutputToStd = false;	// By default all random bytes should be written to a file
	isDataOutputToEP = false;
	filePathName = NULL;
	this->argc = argc;
	this->argv = argv;
}

/**
 * Process command line arguments
 *
 * @return int - 0 when run successfully
 */
int TL100Util::process() {
	if (argc == 1) {
		displayUsage();
		return -1;
	}
	return processArguments(argc, argv);
}

/**
 * Validate command line argument count
 *
 * @param int curIdx 
 * @param int actualArgumentCount
 * @return bool - true if run successfully
 */
bool TL100Util::validateArgumentCount(int curIdx, int actualArgumentCount) {
	if (curIdx >= actualArgumentCount) {
		fprintf(stderr, "\nMissing command line arguments\n\n");
		displayUsage();
		return false;
	}
	return true;
}

/**
 * Display information about FTDI and TL devices
 *
 * @return int - 0 when run successfully
 */
int TL100Util::listDevices() {
	TL100 tl;
	DeviceInfoList dil;

	int status = tl.listDevices(&dil);

	if ( status != FT_OK) {
		fprintf(stderr, "Could not generate FT device info list, status: %d\n", status);
		return status;
	}

	if (dil.numDevs > 0) {
		printf("\n");
		for (DWORD i = 0; i < dil.numDevs; i++) {
			printf("{");
				printf("DevNum=%d",i); 
				if (dil.devInfoList[i].comPortNumber > 0) {
					printf(" WinPort=COM%d",dil.devInfoList[i].comPortNumber); 
				}
				printf(" ID=0x%x",dil.devInfoList[i].usbID); 
				printf(" LocId=0x%x",dil.devInfoList[i].usbLocId); 
				printf(" UsbCfg=%s",dil.devInfoList[i].usbConfigID); 
				printf(" DevModel=%s",dil.devInfoList[i].deviceModel); 
				printf(" DevVer=%s",dil.devInfoList[i].deviceVersion); 
				printf(" DevS/N=%s",dil.devInfoList[i].deviceSerialNumber); 
			printf("}\n");
		}
	} else {
		printf("There are currently no TL100 devices detected\n");
	}
	return FT_OK;
}

/**
 * Parse arguments for extracting command line parameters
 *
 * @param int argc
 * @param char** argv
 * @return int - 0 when run successfully
 */
int TL100Util::processArguments(int argc, char **argv) {
	int idx = 1;
	if (strcmp("-ld", argv[idx]) == 0 || strcmp("--list-devices", argv[idx]) == 0 ) {
		return listDevices();
	} else if (strcmp("-dd", argv[idx]) == 0 || strcmp("--download-data", argv[idx]) == 0 ) {
		if (validateArgumentCount(++idx, argc) == false) {
			return -1;
		}
		while( idx < argc) {
			if (strcmp("-nb", argv[idx]) == 0 || strcmp("--number-bytes", argv[idx]) == 0 ) {
				if (validateArgumentCount(++idx, argc) == false) {
					return -1;
				}
				numGenBytes = atoll(argv[idx++]);
				if (numGenBytes > 200000000000) {
					fprintf(stderr, "Number of bytes cannot exceed 200000000000\n");
					return -1;
				}
			} else if (strcmp("-wtso", argv[idx]) == 0 || strcmp("--write-to-stdout", argv[idx]) == 0 ) {
				isDataOutputToStd = true;
				idx++;
#ifdef __linux__
			} else if (strcmp("-fep", argv[idx]) == 0 || strcmp("--feed-entropy-pool", argv[idx]) == 0 ) {
				isDataOutputToEP = true;
				idx++;
#endif
			} else if (strcmp("-fdpp", argv[idx]) == 0 || strcmp("--force-device-post-processing", argv[idx]) == 0 ) {
				tl.setDevicePostProcessing(true);
				idx++;
			} else if (strcmp("-fn", argv[idx]) == 0 || strcmp("--file-name", argv[idx]) == 0 ) {
				if (validateArgumentCount(++idx, argc) == false) {
					return -1;
				}
				filePathName = argv[idx++];
			} else if (strcmp("-dn", argv[idx]) == 0 || strcmp("--device-number", argv[idx]) == 0 ) {
				if (validateArgumentCount(++idx, argc) == false) {
					return -1;
				}
				deviceNum = atoi(argv[idx++]);
				if (deviceNum < 0) {
					fprintf(stderr, "Device number cannot be a negative value\n");
					return -1;
				}
			} else if (strcmp("-gm", argv[idx]) == 0 || strcmp("--generator-mode", argv[idx]) == 0 ) {
				if (validateArgumentCount(++idx, argc) == false) {
					return -1;
				}
				genMode = argv[idx++];

				if (strcmp("r", genMode) == 0) {
					tl.setRawMode();
				} else if (strcmp("lb", genMode) == 0) {
					tl.setLowBiasMode();
				} else if (strcmp("h2", genMode) == 0) {
					tl.setSHA2Mode();
				} else if (strcmp("hmac", genMode) == 0) {
					tl.setHMACMode();
				} else if (strcmp("h1", genMode) == 0) {
					tl.setSHA1Mode();
				} else if (strcmp("h512", genMode) == 0) {
					tl.setSHA512Mode();
				} else {
					fprintf(stderr, "Invalid argument: %s \n\n", genMode);
					displayUsage();
					return -1;
				}
			} else {
				// Could not handle the argument, skip to the next one
				++idx;
			}
		} 
	} 
#ifdef _WIN32
	else if (strcmp("-uis", argv[idx]) == 0 || strcmp("--user-interactive-session", argv[idx]) == 0 ) {
		if (argc > idx + 1) {
			deviceNum = atoi(argv[idx + 1]);
			if (deviceNum < 0) {
				fprintf(stderr, "Invalid device number\n");
				return -1;
			}
		}
		return handleUserInteractiveSession();
	}
#endif
	if (isDataOutputToStd == false) {
		printf("Processing request ... ");
	}
#ifdef __linux__
	if (isDataOutputToEP) {
		return feedKernelEntropyPool();
	}
#endif
	return processDownloadRequest();
}

//.............
#ifdef __linux__
//.............
/**
 * Feed Kernel entropy pool with true random bytes
 *
 * @return int - 0 when run successfully
 */
int TL100Util::feedKernelEntropyPool() {

	int status = tl.open(deviceNum);
	if(status != FT_OK) {
		fprintf(stderr, "Cannot open device, error code %d ... ", status);
		tl.close();
		return status;
	}

	int rndout = open(KERNEL_ENTROPY_POOL_NAME, O_WRONLY);
	if (rndout < 0) {
		printf("Cannot open %s : %d\n", KERNEL_ENTROPY_POOL_NAME, rndout);
		tl.close();
		return rndout;
	}

	// Check to see if we have privileges for feeding the entropy pool
	int result = ioctl(rndout, RNDGETENTCNT, &entropyAvailable);
	if (result < 0) {
		printf("Cannot verify available entropy in the pool, make sure you run this utility with CAP_SYS_ADMIN capability\n");
		tl.close();
		close(rndout);
		return result;
	}

	printf("Feeding the kernel %s entropy pool. Initial amount of entropy bits in the pool: %d ...\n", KERNEL_ENTROPY_POOL_NAME, entropyAvailable);

	while(true) {
		// Infinite loop for feeding kernel entropy pool
		status = tl.getBytes(entropy.data, KERNEL_ENTROPY_POOL_SIZE_BYTES);
		if(status != FT_OK) {
			fprintf(stderr, "Failed to receive %d bytes for feeding entropy pool, error code %d. ", BUFF_SIZE_BYTES, status);
			fprintf(stderr, "%s\n", tl.getLastErrMsg());
			tl.close();
			return status;
		}
		// Check to see if we need more entropy
		ioctl(rndout, RNDGETENTCNT, &entropyAvailable);
		if (entropyAvailable < KERNEL_ENTROPY_POOL_SIZE_BYTES * 8) {
			int addMoreBytes = KERNEL_ENTROPY_POOL_SIZE_BYTES - (entropyAvailable >> 3);
			entropy.buf_size = addMoreBytes;
			entropy.entropy_count = addMoreBytes << 3;
			result = ioctl(rndout, RNDADDENTROPY, &entropy);
			if (result < 0) {
				printf("Cannot add more entropy to the pool, error: %d\n", result);
				tl.close();
				close(rndout);
				return result;
			}
		}
	}

}
//.............
#endif
//.............


/**
 * Process Request
 *
 * @return int - 0 when run successfully
 */
int TL100Util::processDownloadRequest() {
	int status = handleDownloadRequest();
	DeviceStatistics *ds = tl.generateDeviceStatistics();
	if (isDataOutputToStd == false) {
		printf("Completed in %d seconds, speed: %d KBytes/sec, blocks re-sent: %d\n", (int)ds->totalTime, (int)ds->downloadSpeedKBsec, (int)ds->totalRetries);
	}
	return status;
}

//.............
#ifdef _WIN32
//.............
/**
 * Handle user interactive session
 *
 * @return int - 0 when run successfully
 */
int TL100Util::handleUserInteractiveSession() {
	uint8_t receiveByte;
	DeviceModel dm;

	// Open device
	int status = tl.open(deviceNum);
	if(status != FT_OK) {
		fprintf(stderr, " Cannot open device, error code %d ... ", status);
		tl.close();
		return status;
	}

	// Validate the device
	status = tl.getDeviceModel(&dm);
	if (status != FT_OK) {
		fprintf(stderr, "No TL100 device detected, error code %d ... ", status);
		tl.close();
		return status;
	}

	// Set appropriate transmission values for user interactive session
	tl.updateTransmissionTimeouts(10, 60);

	// Enter interractive session
	printf("\n");
	printf("You are about to enter the TL100 device user interactive session.\n");
	printf("Press the 'u' key to enter the user interactive menu.\n");
	printf("When entering this mode you will be prompted for a valid pass code.\n");
	printf("When finished, make sure you exit the user session\n");
	printf("back to command mode and then press '.' key to exit this application\n");
	printf("(or disconnect the TL100 device from the USB port and connect it back).\n");
	printf("\n");
	while(1) {
		int cnt = tl.receiveBytes(&receiveByte, 1);
		if (cnt == 1) {
			printf("%c", receiveByte);
		}
		if (cnt == -1) {
			fprintf(stderr, "TL100 transmission error, code %d ... ", status);
			break;
		}
		if (isAnyKeyPressed()) {
#ifdef WIN32
			char cmd = _getch();
#else
			char cmd = getc(stdin);
#endif
			if (cmd == '.') {
				break;
			}
			tl.sendRequest(cmd);
		}
	}

	tl.close();
	return FT_OK;
}

/**
 * Check to see if any key has been pressed and it is available in stdin
 *
 * @return int - 0 when run successfully
 */
bool TL100Util::isAnyKeyPressed() {
	if (_kbhit()) {
		return true;
	} else {
		return false;
	}
}
//..............
#endif
//..............

/**
 * Handle download request
 *
 * @return int - 0 when run successfully
 */
int TL100Util::handleDownloadRequest() {

	uint8_t receiveByteBuffer[BUFF_SIZE_BYTES + 1]; // Add one extra byte of storage for the status byte

	int status = tl.open(deviceNum);
	if(status != FT_OK) {
		fprintf(stderr, " Cannot open device, error code %d ... ", status);
		tl.close();
		return status;
	}

	if (!isDataOutputToStd) {

		if (filePathName == NULL) {
			fprintf(stderr, "No file name defined. ");
			tl.close();
			return -1;
		}
		pOutputFile = fopen(filePathName, "wb");
		if (pOutputFile == NULL) {
			fprintf(stderr, "Cannot open file: %s in write mode\n", filePathName);
			tl.close();
			return -1;
		}
	}

	while(numGenBytes == -1) {
		// Infinite loop for downloading unlimited random bytes
		status = tl.getBytes(receiveByteBuffer, BUFF_SIZE_BYTES);
		if(status != FT_OK) {
			fprintf(stderr, "Failed to receive %d bytes for unlimited download, error code %d. ", BUFF_SIZE_BYTES, status);
			fprintf(stderr, "%s\n", tl.getLastErrMsg());
			closeHandle();
			tl.close();
			return status;
		}
		writeBytes(receiveByteBuffer, BUFF_SIZE_BYTES);
	}

	// Calculate number of complete random byte chunks to download
	int64_t numCompleteChunks = numGenBytes / BUFF_SIZE_BYTES;

	// Calculate number of bytes in the last incomplete chunk
	uint32_t chunkRemaindBytes = (uint32_t)(numGenBytes % BUFF_SIZE_BYTES);

	// Process each chunk
	int64_t chunkNum;
	for (chunkNum = 0; chunkNum < numCompleteChunks; chunkNum++) {
		status = tl.getBytes(receiveByteBuffer, BUFF_SIZE_BYTES);
		if (status != FT_OK) {
			fprintf(stderr, "Failed to receive %d bytes, error code %d. ", BUFF_SIZE_BYTES, status);
			fprintf(stderr, "%s\n", tl.getLastErrMsg());
			closeHandle();
			tl.close();
			return status;
		}
		writeBytes(receiveByteBuffer, BUFF_SIZE_BYTES);

	}

	if (chunkRemaindBytes > 0) {
		//Process incomplete chunk
		status = tl.getBytes(receiveByteBuffer, chunkRemaindBytes);
		if (status != FT_OK) {
			fprintf(stderr, "Failed to receive %d bytes for last chunk, error code %d. ", chunkRemaindBytes, status);
			fprintf(stderr, "%s\n", tl.getLastErrMsg());
			closeHandle();
			tl.close();
			return status;
		}
		writeBytes(receiveByteBuffer, chunkRemaindBytes);
	}

	closeHandle();
	tl.close();
	return FT_OK;
}

/**
 * Write bytes out
 *
 * @param uint8_t* bytes - pointer to the byte array
 * @param uint32_t numBytes - number of bytes to write
 */
void TL100Util::writeBytes(uint8_t *bytes, uint32_t numBytes) {
	FILE *handle = pOutputFile;
	if (isDataOutputToStd) {
		handle = stdout;
	}
	fwrite(bytes, 1, numBytes, handle);
}

/**
 * Close file handle
 *
 */
void TL100Util::closeHandle() {
	if (!isDataOutputToStd) {
		if (pOutputFile != NULL) {
			fclose(pOutputFile);
		}
	}
}

/**
 * Display usage message
 *
 */
void TL100Util::displayUsage() {
	printf("***********************************************************\n");
	printf("          TectroLabs - TL100 - download utility Ver 1.6.4 \n");
	printf("***********************************************************\n");

	printf("NAME\n");
	printf("     getrnd  - True Random Number Generator TL100 download \n");
	printf("               utility \n");
	printf("SYNOPSIS\n");
#ifdef _WIN32
	printf("     getrnd -ld --list-devices | -dd --download-data [options]\n");
	printf("                               | -uis --user-interactive-session \n");
#else
	printf("     getrnd -ld --list-devices | -dd --download-data [options] \n");
#endif
	printf("\n");
	printf("DESCRIPTION\n");
	printf("     Getrnd downloads random bytes from Hardware (True) \n");
	printf("     Random Number Generator TL100 device and writes them to a \n");
	printf("     binary file or sends them to standard output\n");
	printf("\n");
	printf("FUNCTION LETTERS\n");
	printf("     Main operation mode:\n");
	printf("\n");
	printf("     -ld, --list-devices\n");
	printf("           list all available (not currently in use) TL100 devices\n");
	printf("\n");
	printf("     -dd, --download-data\n");
	printf("           download random bytes from the TL100 device and store \n");
	printf("           them into a file\n");
	printf("\n");
#ifdef _WIN32
	printf("     -uis, --user-interactive-session DEVICE\n");
	printf("           activate user interactive session for the DEVICE number. \n");
	printf("           DEVICE number can be ignored if there is only one TL100 \n");
	printf("           device attached, use '-ld' command to list all available devices\n");
#endif	
	printf("\n");
	printf("OPTIONS\n");
	printf("     Operation modifiers:\n");
	printf("\n");
	printf("     -wtso, --write-to-stdout\n");
	printf("           Write random binary bytes to standard output. Not to be used\n");
	printf("           with Windows OS since it may include extra bytes when streaming\n");
	printf("           to standard output.\n");
	printf("\n");
#ifdef __linux__
	printf("     -fep, --feed-entropy-pool\n");
	printf("           Feed /dev/random Kernel entropy pool with true random numbers.\n");
	printf("           It will continuously maintain /dev/random pool filled up with\n");
	printf("           true random bytes.\n");
	printf("\n");
#endif
	printf("     -fdpp, --force-device-post-processing\n");
	printf("           all post processing logic will run by TL100 device, using\n");
	printf("           this option will slow down generation speed and should only\n");
	printf("           be used when connected to a host with limited CPU resources\n");
	printf("\n");
	printf("     -fn, --file-name FILE\n");
	printf("           a FILE name for storing random data\n");
	printf("\n");
	printf("     -nb, --number-bytes NUMBER\n");
	printf("           NUMBER of random bytes to download into a file, max value\n");
	printf("           200000000000, skip this option for unlimited amount of random\n");
	printf("           bytes (continuous download)\n");
	printf("\n");
	printf("     -dn, --device-number\n");
	printf("           USB device number, if more than one, skip this option if only\n");
	printf("           one TL100 device is connected, use '-ld' to list all available\n");
	printf("           devices\n");
	printf("\n");
	printf("     -gm, --generator-mode MODE\n");
	printf("           TL100 generator MODE: 'h2'-SHA256 data mode, 'h1'-SHA160 data mode,\n");
	printf("                                 'r'-raw data mode, 'lb'-low bias data mode,\n");
	printf("                                 'hmac'-HMAC data mode, 'h512'-SHA512 mode,\n");
	printf("           skip this option for using default (SHA256) recommended mode\n");
	printf("\n");
	printf("\n");
	printf("EXAMPLES:\n");
	printf("     To list all available TL100 (not currently in use) devices.\n");
	printf("           getrnd -ld\n");
	printf("     To download 12 MB of true random bytes using device 0 (default) and 'h2'\n");
	printf("           (default) mode and store in the 'rnd.bin' file.\n");
	printf("           getrnd  -dd -fn rnd.bin -nb 12000000\n");
#ifdef __linux__
	printf("     To feed Kernel /dev/random entropy pool.\n");
	printf("           getrnd  -dd -fep\n");
#endif
#ifdef _WIN32
	printf("     To activate the TL100 user interactive session using device 0 (default)\n");
	printf("           getrnd  -uis\n");
#endif
	printf("\n");
}