#include "stdafx.h"
/*
 * SHA256.cpp
 * ver. 1.6.4
 *
 */

/*********************************************************************************************

Copyright � 2013 TectroLabs, http://tectrolabs.com

THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

This class implements SHA-256 hashing algorithm based on 'FIPS PUB 180-4' publication 
for Secure Hash Standard (SHS) 2012 by National Institute of Standards and Technology (NIST).

Implementation exceptions: 
This SHA-2 implementation is stateless and operates only on 32 bit words.
It should only be used with the TL100 device as a bias remover. 

This class may only be used in conjunction with the TL100 device.

*********************************************************************************************/

#include "SHA256.h"

#define ROTR(sb,w) (((w) >> (sb)) | ((w) << (32-(sb))))

const uint32_t SHA256::k[64] = {
	0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
	0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
	0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
	0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
	0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
	0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
	0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
	0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
};

const uint8_t SHA256::maxDataBlockSizeWords = 16;
const uint16_t SHA256::minInputNumWords = 10;
const uint16_t SHA256::outputNumWords = 8;

/**
 * Initialize the instance
 *
 */
inline void SHA256::initialize() {

	// Initialize H0, H1, H2, H3, H4, H5, H6 and H7
	h0 = 0x6a09e667;
	h1 = 0xbb67ae85;
	h2 = 0x3c6ef372;
	h3 = 0xa54ff53a;
	h4 = 0x510e527f;
	h5 = 0x9b05688c;
	h6 = 0x1f83d9ab;
	h7 = 0x5be0cd19;
}

/**
 * Retrieve the minimum number of words required for hash input block
 *
 * @return uint16_t number of words in the hashing input block
 */
uint16_t SHA256::getMinInputNumWords() {
	return minInputNumWords;
}

/**
 * Retrieve the number of words for the hash output
 *
 * @return uint16_t number of words for the hash output
 */
uint16_t SHA256::getOutputNumWords() {
	return outputNumWords;
}

/**
 * Retrieve the number of bytes in the word 
 * used by this specific hashing implementation
 *
 * @return uint16_t word size in bytes
 */
uint16_t SHA256::getWordSizeBytes() {
	return 4;
}

/**
 * Stamp a new serial number for the input data block into the last word
 * 
 * @param void* inputBlock pointer to the input hashing block
 * 
 */
void SHA256::stampSerialNumber(void *inputBlock) {
	uint32_t *inw = (uint32_t*)inputBlock;
	inw[minInputNumWords] = blockSerialNumber++;
};

/**
 * Initialize the serial number for hashing
 * 
 * @param uint32_t initValue - a startup random number for generating serial number for hashing
 * 
 */
void SHA256::initializeSerialNumber(uint32_t initValue) {
	blockSerialNumber = initValue;
}

/**
 * Generate SHA256 value.
 * 
 * @param void* src - pointer to an array of 32 bit words used as hash input
 * @param void* dst - pointer to an array of 8 X 32 bit words used as hash output
 * @param int16_t* len - number of 32 bit words available in array pointed by 'src'
 *
 * @return int 0 for successful operation, -1 for invalid parameters
 * 
 */
int SHA256::generateHash(void *src, int16_t len, void *dst) {
	return generateHash((uint32_t*)src, len, (uint32_t*)dst);
}

/**
 * Generate SHA256 value. 
 * 
 * @param uint32_t* src - pointer to an array of 32 bit words used as hash input
 * @param uint32_t dst - pointer to an array of 8 X 32 bit words used as hash output
 * @param int16_t len - number of 32 bit words available in array pointed by 'src'
 *
 * @return int 0 for successful operation, -1 for invalid parameters
 * 
 */
int SHA256::generateHash(uint32_t *src, int16_t len, uint32_t *dst) {

	if (len <= 0) {
		return -1;
	}

	initialize();

	int32_t initialMessageSize = len * 8 * 4;
	uint16_t numCompleteDataBlocks = len / maxDataBlockSizeWords;
	uint16_t reminder = len % maxDataBlockSizeWords;

	// Process complete blocks
	for (uint16_t blockNum = 0; blockNum < numCompleteDataBlocks; blockNum++) {
		uint16_t srcOffset = blockNum * maxDataBlockSizeWords;
		for (uint8_t ui8 = 0; ui8 < maxDataBlockSizeWords; ui8++) {
			w[ui8] = src[ui8 + srcOffset];
		}
		// Hash the current block
		hashCurrentBlock();
	}

	uint16_t srcOffset = numCompleteDataBlocks * maxDataBlockSizeWords;
	uint8_t needAdditionalBlock = 1;
	uint8_t needToAddOneMarker = 1;
	if (reminder > 0) {
		// Process the last data block if any
		uint8_t ui8 = 0;
		for (; ui8 < reminder; ui8++) {
			w[ui8] = src[ui8 + srcOffset];
		}
		// Append '1' to the message
		w[ui8++] = 0x80000000;
		needToAddOneMarker = 0;
		if (ui8 < maxDataBlockSizeWords - 1) {
			for (; ui8 <  maxDataBlockSizeWords - 2; ui8++) {
				// Fill with zeros
				w[ui8] = 0x0;
			}
			// add the message size to the current block
			w[ui8++] = 0x0;
			w[ui8] = initialMessageSize;
			hashCurrentBlock();
			needAdditionalBlock = 0;
		} else {
			// Fill the rest with '0'
			// Will need to create another block
			w[ui8] = 0x0;
			hashCurrentBlock();
		}
	}

	if (needAdditionalBlock) {
		uint8_t ui8 = 0;
		if (needToAddOneMarker) {
			w[ui8++] = 0x80000000;
		}
		for (; ui8 <  maxDataBlockSizeWords - 2; ui8++) {
			w[ui8] = 0x0;
		}
		w[ui8++] = 0x0;
		w[ui8] = initialMessageSize;
		hashCurrentBlock();
	}

	// Save the results
	dst[0] = h0;
	dst[1] = h1;
	dst[2] = h2;
	dst[3] = h3;
	dst[4] = h4;
	dst[5] = h5;
	dst[6] = h6;
	dst[7] = h7;

	return 0;
}

/**
 * Hash current block
 * 
 */
inline void SHA256::hashCurrentBlock() {

	// Process elements 16...63
	for (uint8_t t = 16; t <= 63; t++) {
		w[t] = sigma1(&w[t-2]) + w[t-7] + sigma0(&w[t-15]) + w[t-16];
	}

	// Initialize variables
	a = h0;
	b = h1;
	c = h2;
	d = h3;
	e = h4;
	f = h5;
	g = h6;
	h = h7;

	// Process elements 0...63
	for (uint8_t t = 0; t <= 63; t++) {
		tmp1 = h + sum1(&e) + ch(&e, &f, &g) + k[t] + w[t];
		tmp2 = sum0(&a) + maj(&a, &b, &c);
		h = g;
		g = f;
		f = e;
		e = d + tmp1;
		d = c;
		c = b;
		b = a;
		a = tmp1 + tmp2;
	}

	// Calculate the final hash for the block
	h0 += a;
	h1 += b;
	h2 += c;
	h3 += d;
	h4 += e;
	h5 += f;
	h6 += g;
	h7 += h;
}

/**
 * FIPS PUB 180-4 section 4.1.2 formula (4.2)
 *
 * @param uint32_t* x pointer to variable x
 * @param uint32_t* y pointer to variable y
 * @param uint32_t* z pointer to variable z
 * $return uint32_t Ch value
 * 
 */
inline uint32_t SHA256::ch(uint32_t *x, uint32_t *y, uint32_t *z) {
	return  ((*x) & (*y)) ^ (~(*x) & (*z));
}

/**
 * FIPS PUB 180-4 section 4.1.2 formula (4.3)
 *
 * @param uint32_t* x pointer to variable x
 * @param uint32_t* y pointer to variable y
 * @param uint32_t* z pointer to variable z
 * $return uint32_t Maj value
 * 
 */
inline uint32_t SHA256::maj(uint32_t *x, uint32_t *y, uint32_t *z) {
	return ((*x) & (*y)) ^ ((*x) & (*z)) ^ ((*y) & (*z));
}

/**
 * FIPS PUB 180-4 section 4.1.2 formula (4.4)
 *
 * @param uint32_t* x pointer to variable x
 * $return uint32_t Sum0 value
 * 
 */
inline uint32_t SHA256::sum0(uint32_t *x) {
	return ROTR(2, *x) ^ ROTR(13, *x) ^ ROTR(22, *x);
}

/**
 * FIPS PUB 180-4 section 4.1.2 formula (4.5)
 *
 * @param uint32_t* x pointer to variable x
 * $return uint32_t Sum1 value
 * 
 */
inline uint32_t SHA256::sum1(uint32_t *x) {
	return ROTR(6, *x) ^ ROTR(11, *x) ^ ROTR(25, *x);
}

/**
 * FIPS PUB 180-4 section 4.1.2 formula (4.6)
 *
 * @param uint32_t* x pointer to variable x
 * $return uint32_t sigma0 value
 * 
 */
inline uint32_t SHA256::sigma0(uint32_t *x) {
	return ROTR(7, *x) ^ ROTR(18, *x) ^ ((*x) >> 3);
}

/**
 * FIPS PUB 180-4 section 4.1.2 formula (4.7)
 *
 * @param uint32_t* x pointer to variable x
 * $return uint32_t sigma1 value
 * 
 */
inline uint32_t SHA256::sigma1(uint32_t *x) {
	return ROTR(17, *x) ^ ROTR(19, *x) ^ ((*x) >> 10);
}
