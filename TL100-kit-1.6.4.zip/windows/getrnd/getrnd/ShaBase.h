/*
 * ShaBase.h
 * ver. 1.6.4
 *
 */

/************************************************************************

Copyright � 2013 TectroLabs, http://tectrolabs.com

THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

It is an abstract base class used for hashing algorithm implementation.

This class may only be used in conjunction with the TL100 device.

*************************************************************************/

#ifndef SHABASE_H_
#define SHABASE_H_

#include <stdint.h>

class ShaBase {
	public:
		virtual int generateHash(void *src, int16_t len, void *dst) = 0;
		virtual uint16_t getMinInputNumWords() = 0;
		virtual uint16_t getOutputNumWords() = 0;
		virtual uint16_t getWordSizeBytes() = 0;
		virtual void stampSerialNumber(void *inputBlock) = 0;
};


#endif /* SHABASE_H_ */