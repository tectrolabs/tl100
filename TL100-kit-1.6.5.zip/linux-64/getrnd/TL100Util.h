/*
 * TL100FILE.h
 * ver. 1.6.5
 *
 */

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Copyright � 2013 TectroLabs, http://tectrolabs.com

THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

This class is for interacting with the hardware random data generator device TL100 for the purpose of downloading
random bytes into a file. The TL100 device should be connected to an available USB port and a proper USB driver should be installed. 

Please refer to README.doc document for USB driver installation instructions and for OS compatibility information.

This class uses the FTDI D2XX driver for interacting with the TL100 device.

This class may only be used in conjunction with the TL100 device.

This utility will require 'sudo' permissions when running in a Linux environment.

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/


#ifndef TL100FILE_H_
#define TL100FILE_H_


#include "TL100.h"
#include <stdio.h>

#ifdef WIN32
 #include <conio.h>
#endif

#ifdef __linux__
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/random.h>

#define KERNEL_ENTROPY_POOL_SIZE_BYTES 512
#define KERNEL_ENTROPY_POOL_NAME "/dev/random"
#endif

class TL100Util {

	public:
		void initialize(int argc, char **argv);
		int	process();

	private:
		int  deviceNum;			// USB device number starting with 0 (a command line argument)
		char *filePathName;		// File name for recording the random bytes (a command line argument)
		char *genMode;			// Data generation mode (a command line argument)
		int64_t numGenBytes;	// Total number of random bytes needed (a command line argument) max 100000000000 bytes
		FILE *pOutputFile;		// Output file handle
		int argc;				// Number of command line arguments
		char **argv;			// Pointer to command line arguments
		TL100 tl;				// TL100 driver
		bool isDataOutputToStd; // True if random bytes should be written to standard output instead of a file
		bool isDataOutputToEP;	// True if random bytes should be written to Kernel entropy pool instead of a file
#ifdef __linux__
		int entropyAvailable;	// A variable for checking the amount of the entropy available in the kernel pool
		struct {
			int	entropy_count;
			int	buf_size;
			unsigned char data[KERNEL_ENTROPY_POOL_SIZE_BYTES + 1];
		} entropy;
#endif

	private:
		void displayUsage();	// Display menu options
		int processArguments(int argc, char **argv);
		bool validateArgumentCount(int curIdx, int actualArgumentCount);
		int listDevices();
		int processDownloadRequest();
#ifdef __linux__
		int feedKernelEntropyPool();
#endif
#ifdef _WIN32
		int handleUserInteractiveSession();
#endif
		bool isAnyKeyPressed();
		int handleDownloadRequest();
		void closeHandle();
		void writeBytes(uint8_t *bytes, uint32_t numBytes);

};


#endif /* TL100FILE_H_ */