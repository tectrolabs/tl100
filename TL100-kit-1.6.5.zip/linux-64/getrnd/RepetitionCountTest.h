/*
 * RepetitionCountTest.h
 * ver. 1.6.5
 *
 */ 

/*********************************************************************************************

Copyright � 2013 TectroLabs, http://tectrolabs.com

THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

This class implements Repetition Count Test algorithm based on 'NIST SP 800-90B' publication 
section 6.5.1.2 by National Institute of Standards and Technology (NIST) 2012.

This class may only be used in conjunction with the TL100 device.

*********************************************************************************************/


#ifndef REPETITIONCOUNTTEST_H_
#define REPETITIONCOUNTTEST_H_

#include <stdint.h>

class RepetitionCountTest {
	private:
		uint32_t maxRepetitions;
		uint32_t curRepetitions;
		uint8_t lastSample;
		uint8_t *statusByte;
		uint8_t signature;
		bool isInitialized;
		uint32_t failureWindow;
		uint16_t failureCount;
	public:
		void initialize(uint8_t *statusByte);
		void restart();
		void sample(uint8_t value);

	private:
		static const uint8_t numConsecFailThreshold;
};



#endif /* REPETITIONCOUNTTEST_H_ */