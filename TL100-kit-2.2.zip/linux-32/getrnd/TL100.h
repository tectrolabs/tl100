/*
 * TL100.h
 * ver. 2.1
 *
 */

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Copyright (C) 2013-2015 TectroLabs, http://tectrolabs.com

THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

This class is used as a software API for interacting with the hardware random data generator device TL100 for the purpose of
downloading random bytes. The TL100 device should be connected to an available USB port and a proper USB driver should be 
installed. 

Please refer to README.doc document for USB driver installation instructions and for OS compatibility information.

This class uses the FTDI D2XX driver for interacting with the TL100 device.

This class may only be used in conjunction with the TL100 device.

This utility will require 'sudo' permissions when running in a Linux environment.

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/


#ifndef TL100_H_
#define TL100_H_

#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <string.h>
#include <stdio.h>

#include "ShaBase.h"
#include "SHA256.h"
#include "MemoryBuffer.h"
#include "AdaptiveProportionTest.h"
#include "RepetitionCountTest.h"
#include "ftd2xx.h"

#ifndef WIN32
 #include <unistd.h>
#endif

struct DeviceSerialNumber {
	char value[31];	// Device serial number (ASCIIZ)
};

struct DeviceVersion {
	char value[4];	// Device version (ASCIIZ)
};

struct DeviceModel {
	char value[7];	// Device model (ASCIIZ)
};

struct DeviceStatistics {
	int64_t numGenBytes;					// Total number of random bytes generated
	int64_t totalRetries;					// Total number of download re-transmissions
	time_t beginTime, endTime, totalTime;	// Used for measuring performance
	int downloadSpeedKBsec;					// Measured download speed in KB/sec
};

struct DeviceInfo {
	DWORD devNum;					// Logical device number
	ULONG usbID;					// FTDI specific device ID 
	DWORD usbLocId;					// FTDI specific location ID
	char usbConfigID[16];			// FTDI specific serial number or configuration ID
	char deviceModel[11];			// Device model for example: TL100
	char deviceVersion[11];			// Device version for example: 1.6
	char deviceSerialNumber[31];	// Unique device serial number
	int comPortNumber;				// Windows Com port number or -1 if not found
	DWORD prodID;					// USB product ID
};

struct DeviceInfoList {
	DeviceInfo devInfoList[50];		// Array of DeviceInfo
	DWORD numDevs;					// Actual number of elements in devInfoList array
};


class TL100 {

	public:
		TL100();
		virtual ~TL100();
		int open(int deviceNum);	// Open FTDI USB specific device (0 - first TL100 device)
		int openLastUsedDevice();	// Re-open FTDI device based on the last known USB serial number
		int close();				// Close FTDI USB device if open
		void setRawMode();			// Use RAW mode for downloading RAW (unprocessed) random bytes
		void setSHA1Mode();			// Use SHA160 post processing for bias remover
		void setSHA2Mode();			// Use SHA256 post processing for bias remover
		void setSHA512Mode();		// Use SHA512 post processing for bias remover
		void setHMACMode();			// Use HMAC-SHA160 post processing for bias remover
		void setLowBiasMode();		// Use this mode for downloading low bias random bytes
		void enableAutoRecoverMode();	// Ebable this mode to auto recover from lost connection to remote TL100 device
		void disableAutoRecoverMode();	// Disable auto recover mode
		int getBytes(uint8_t *dest, uint32_t len);	// Download random bytes. 'dest' should point to a buffer of len+1 bytes
		int getDeviceSerialNumber(DeviceSerialNumber *serialNumber);	// Retrieve unique serial number of the TL100 device
		int getDeviceVersion(DeviceVersion *version);	// Retrieve device version
		int getDeviceModel(DeviceModel *model);			// Retrieve device model
		void resetDeviceStatistics();	// Reset the download device statistics 
		DeviceStatistics* generateDeviceStatistics();	// Generate device statistics report
		int listDevices(DeviceInfoList *devInfoList);	// Retrieve a list of TL100 devices connected to the host
		void setDevicePostProcessing(bool fdpp);
		char *getLastErrMsg();		// Retrieve the last error message
		int sendRequest(char cmd);
		int receiveBytes(uint8_t *dest, uint16_t byteCnt);
		int updateTransmissionTimeouts(ULONG rcvto, ULONG sendto);
		int readEEPROM(FT_PROGRAM_DATA *ftData);
		int writeEEPROM(FT_PROGRAM_DATA *ftData);


	private:
		int deviceNum;				// USB device number starting with 0
		FT_STATUS ftStatus;			// FTDI driver status code
		FT_HANDLE ftHandle;			// FTDI USB device handle
		bool deviceOpen;			// True if device successfully open
		ULONG baudRate;				// Data communication speed used for downloading random bit stream.
		ULONG sendTimeOutMlSecs;	// Device Transmission time out in milliseconds
		ULONG receiveTimeOutMlSecs;	// Device Receive time out in milliseconds
		char genMode;				// Random post processing data generation mode: 'r', 'x' '1', '2' or 'h' 
		uint8_t maxRetriesPerChunk;	// Retry count used for downloading one chunk of bit stream before throwing an error.
		DeviceStatistics ds;
		SHA256 sha256;
		AdaptiveProportionTest apt;
		RepetitionCountTest rct;
		MemoryBuffer mb;
		MemoryBuffer hmb;
		MemoryBuffer imb;
		MemoryBuffer lastErrMsg;
		bool isPostProcessingOnDevice;
		uint8_t statusByte;			// Success value is 0
		bool autoRecoverMode;		// True when auto recover mode is enabled
		char curFTDISerialNumber[16];  // Serial number of the current FTDI device 
		int openDevLeftCount;		// Number of times left to re-opeen the device before setting failure condition	
		int sleepReOpenMlsecs;		// Number of milliseconds to sleep before re-establishing the lost communication with the device
		char ManufacturerBuf[256];	// Variable needed for EEPROM read operation
		char ManufacturerIdBuf[256];// Variable needed for EEPROM read operation
		char DescriptionBuf[256];	// Variable needed for EEPROM read operation
		char SerialNumberBuf[256];	// Variable needed for EEPROM read operation

	private:
		void initialize();
		void initializePlatform();
		void saveFTDISerialNumber(int deviceNum);
		void initDeviceReOpenCnt();
		FT_STATUS openDeviceNum(int dn, FT_HANDLE *handle);
		int getBytes(uint8_t *dest, uint16_t byteCnt, char cmd);
		int sendRequest(uint16_t byteCnt, char cmd);
		uint16_t getDeviceBytes(uint8_t *dest, uint16_t byteCnt);
		int getDeviceBytes(uint8_t *dest, uint32_t numGenBytes, char genMode);
		int hostHashing(uint8_t *dest, uint32_t numGenBytes);
		ShaBase *getHashImpl();
		void setLastErrMsg(const char *msg);
		int processOneByteCmd(uint8_t *dest, uint16_t byteCnt, char cmd);
		void clearLastErrMsg();
		void sleepMlSecs(int mlsecs);

};


#endif /* TL100_H_ */
