#include "stdafx.h"

/*
 * getrnd.c 
 * ver. 2.1
 *
 */ 


#include "TL100Util.h"


/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Copyright (C) 2013-2015 TectroLabs, http://tectrolabs.com

THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

This is command line utility used for interacting with the hardware random number generator TL100 device using USB (2/3)
interface for downloading random bytes and for storing them in a file. The TL100 device should be connected
to an available USB port and a proper USB driver should be installed prior to running this utility. 
Please refer to README.doc document for USB driver installation instructions and for OS compatibility information.

This utility is using the FTDI D2XX driver for interacting with the TL100 device.

This utility may only be used in conjunction with the TL100 device.

This utility will require 'sudo' permissions when running in a Linux environment.

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/


//
// Main entry
//
int main(int argc, char **argv) {

	TL100Util ut;
	ut.initialize(argc, argv);
	return ut.process();

}
