#include "stdafx.h"
/*
 * RepetitionCountTest.cpp
 * ver. 2.1
 *
 */ 

#include "RepetitionCountTest.h"

/*********************************************************************************************

Copyright (C) 2013-2015 TectroLabs, http://tectrolabs.com

THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

This class implements Repetition Count Test algorithm based on 'NIST SP 800-90B' publication 
section 6.5.1.2 by National Institute of Standards and Technology (NIST) 2012.

This class may only be used in conjunction with the TL100 device.

*********************************************************************************************/

const uint8_t RepetitionCountTest::numConsecFailThreshold = 5;

/**
 * Restart the test
 *
 */
void RepetitionCountTest::restart() {
	isInitialized = false;
	curRepetitions = 1;
	failureWindow = 0;
	failureCount = 0;
}

/**
 * Initialize the test.
 *
 * @param statusByte uint8_t* pointer to the status byte
 */
void RepetitionCountTest::initialize(uint8_t *statusByte) {
	this->statusByte = statusByte;
	this->signature = 1;
	maxRepetitions = 5;
	restart();
}

/**
 * Sample a byte
 *
 * @param value uint8_t byte value to test
 */
void RepetitionCountTest::sample(uint8_t value) {
	if (!isInitialized) {
		isInitialized = true;
		lastSample = value;
	} else {
		if (lastSample == value) {
			curRepetitions++;
			if (curRepetitions >= maxRepetitions) {
				curRepetitions = 1;
				if (++failureCount >= numConsecFailThreshold) {
					if ((*statusByte) == 0) {
						*statusByte = signature;
					}						
				}
			}
			
		} else {
			lastSample = value;
			curRepetitions = 1;
		}
	}
}
