/*
 * configure.cpp
 * ver. 2.1
 *
 */

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

 Copyright (C) 2015 TectroLabs, LLC, http://tectrolabs.com

 THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
 INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

 A configuration utility for interacting with the hardware random number generator device TL100
 for the purpose of enabling such device for using with Linux and Mac OSX or Windows operating systems.
 A TL100 RNG device should be connected to an available USB port before running this utility.

 This utility uses the FTDI D2XX driver for interacting with the TL100 device.

 It may only be used in conjunction with TL100 device.

 This utility will require 'sudo' permissions when running in Linux and MAC OSX.

 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#include <iostream>
#include "TL100.h"


bool cmdSetWindows = false;
bool cmdSetLinuxAndOSX = false;
bool cmdListDevices  = false;
int deviceNum = -1;
char deviceName[] = "TL100 ";

// A reserved product ID used with TectroLabs Hardware RNG devices
const int lnxProdID = 0x77d2;

// A reserved product ID by FTDI
const int winProdID = 0x6001;

// The following section should not be modified
char ftdiManuf[] = "FTDI";
char ftdiDesc[] = "FT232R USB UART";
char tlManuf[] = "TL";
char tlDesc[] = "TL100 - Hardware RNG device";

// Messages
char configSuccessMesg[] = "Please unplug the device from the USB port and plug it back in for the changes to take effect.";
char devOpenError[] = "Could not open the device with number ";
char appliedSiccessMsg[] = "Configuration changes have been applied. Your device is ready for use with ";
char tlInvalidModel[] = "Don't know device model ";

/**
 * Configure the device for working with Windows operation systems
 *
 */
void setDeviceForWindows() {
	TL100 tl;
	DeviceModel model;

	if (tl.open(deviceNum)) {
		std::cerr << devOpenError << deviceNum << std::endl;
		return;
	}

	if (tl.getDeviceModel(&model)) {
		std::cerr << devOpenError << deviceNum << std::endl;
		return;
	}

	if (strcmp(model.value, deviceName)) {
		std::cerr << tlInvalidModel << model.value << std::endl;
		return;
	}

	FT_PROGRAM_DATA ftData;
	if (tl.readEEPROM(&ftData)) {
		std::cerr <<"Could not read device configuration" << std::endl;
		tl.close();
		return;
	}

	if (ftData.ProductId == winProdID) {
		std::cerr <<"Device already configured for using with Windows" << std::endl;
		tl.close();
		return;
	}

	ftData.ProductId = winProdID;
	ftData.MaxPower = 200;
	ftData.Manufacturer = ftdiManuf;
	ftData.Description = ftdiDesc;
	ftData.PnP = 1;
	ftData.SelfPowered = 0;

	if (tl.writeEEPROM(&ftData)) {
		std::cerr <<"Could not configure device for using with Windows" << std::endl;
		tl.close();
		return;
	}

	std::cout << std::endl << std::endl;
	std::cout << appliedSiccessMsg << " Windows" << std::endl;
	std::cout << configSuccessMesg << std::endl << std::endl;

	tl.close();
}

/**
 * Configuring the device for working with Linux and MAC OS operation systems
 *
 */
void setDeviceForLinuxAndOSX() {
	TL100 tl;
	DeviceModel model;

	if (tl.open(deviceNum)) {
		std::cerr << devOpenError << deviceNum << std::endl;
		return;
	}

	if (tl.getDeviceModel(&model)) {
		std::cerr << devOpenError << deviceNum << std::endl;
		return;
	}

	if (strcmp(model.value, deviceName)) {
		std::cerr << tlInvalidModel << model.value << std::endl;
		return;
	}

	FT_PROGRAM_DATA ftData;
	if (tl.readEEPROM(&ftData)) {
		std::cerr <<"Could not read device configuration" << std::endl;
		tl.close();
		return;
	}

	if (ftData.ProductId == lnxProdID) {
		std::cerr <<"Device already configured for using with Linux/OS X" << std::endl;
		tl.close();
		return;
	}

	ftData.ProductId = lnxProdID;
	ftData.MaxPower = 200;
	ftData.Manufacturer = tlManuf;
	ftData.Description = tlDesc;
	ftData.PnP = 1;
	ftData.SelfPowered = 0;

	if (tl.writeEEPROM(&ftData)) {
		std::cerr <<"Could not configure device for using with Linux/OS X" << std::endl;
		tl.close();
		return;
	}

	std::cout << std::endl << std::endl;
	std::cout << appliedSiccessMsg << " Linux and Mac OS X" << std::endl;
	std::cout << configSuccessMesg << std::endl << std::endl;

	tl.close();
}

/**
 * List devices and associated information
 */
void listDevices() {
	TL100 tl;
	DeviceInfoList dil;

	int status = tl.listDevices(&dil);

	if ( status != FT_OK) {
		std::cerr <<"Could not generate FT device info list, status:" << status << std::endl;
		return;
	}

	if (dil.numDevs > 0) {
		std::cout << std::endl;
		for (DWORD i = 0; i < dil.numDevs; i++) {
			printf("{");
			std::cout << "DevNum=" << i;
			std::cout << " DevModel=" << dil.devInfoList[i].deviceModel;
			std::cout << " DevVer=" << dil.devInfoList[i].deviceVersion;
			std::cout << " DevS/N=" << dil.devInfoList[i].deviceSerialNumber;
			std::cout << "} ";
			std::cout << "  (configured for ";
			if (dil.devInfoList[i].prodID == 0x77d2) {
				std::cout << "Linux and Mac OS X";
			} else if (dil.devInfoList[i].prodID == 0x6001) {
				std::cout << "Windows";
			} else {
				std::cout << "Unknown: " << (int)dil.devInfoList[i].prodID;
			}
			std::cout << ")" << std::endl;
		}
	} else {
		std::cout << "There are currently no TL100 devices detected" << std::endl;
	}
}

/**
 * Process command according to passed arguments
 */
void processCommand() {
	if (cmdSetWindows) {
		setDeviceForWindows();
	} else if (cmdSetLinuxAndOSX) {
		setDeviceForLinuxAndOSX();
	} else if (cmdListDevices) {
		listDevices();
	} else {
		std::cerr << "Unknown product id" << std::endl;
	}
}

/**
 * Validate arguments
 *
 * @return bool - true if passed parameters are valid and do not conflict with each other
 */
bool validatePrameters() {
	if (!cmdSetWindows && !cmdSetLinuxAndOSX && !cmdListDevices) {
		std::cerr << "Nothing to do" << std::endl;
		return false;
	}
	if (cmdSetWindows && cmdSetLinuxAndOSX && !cmdListDevices) {
		std::cerr << "Cannot configure the device for both Windows and Linux/OS X" << std::endl;
		return false;
	}

	if (cmdListDevices && (cmdSetWindows || cmdSetLinuxAndOSX)) {
		std::cerr << "Cannot list devices and configure the device at the same time" << std::endl;
		return false;
	}

	if ((cmdSetWindows || cmdSetLinuxAndOSX) && deviceNum == -1) {
		std::cerr << "Missing device number when configuring the device" << std::endl;
		return false;
	}
	return true;
}

/**
 * Initialize environment
 *
 */
void initialize() {

#ifdef __linux__
	// The following has been suggested by FTDI and the explanation can be found at the following URL:
	// http://www.ftdichip.com/Drivers/D2XX/Linux/ReadMe-linux.txt
	// Remove these FTDI serial modules from the kernel on Linux environment. The OS will automatically
	// insert them again when using FTDI devices.
	// We only need to use D2XX driver which cannot be used in conjunction with VCP in Linux.
	// We do this only when configuring TL100 device.
	int ret = system("/sbin/rmmod ftdi_sio > /dev/null 2>&1");
	if (ret == -1) {
		printf("Could not remove ftdi_sio module");
	}
	ret = system("/sbin/rmmod usbserial > /dev/null 2>&1");
	if (ret == -1) {
		printf("Could not remove usbserial module");
	}
#else
	// Apple has written a new D2XX driver for OS X, effectively disabling any application which uses the standard D2XX library.
	// Until Apple implements a more permanent fix, this issue can be resolved and the TL100 device can still be used
	// by disabling the new driver.
	// We do this only when configuring TL100 device.
	int ret = system("/sbin/kextunload -b com.apple.driver.AppleUSBFTDI > /dev/null 2>&1");
	if (ret == -1) {
		printf("Could not unload AppleUSBFTDI extension");
	}
#endif

	// Set proper PID For Linux and MAC OS X
	// Product ID 0x77d2 is reserved and should only be used with TectroLabs Hardware RNG devices
	FT_SetVIDPID(0x0403, 0x77d2);
}


/**
 * Display usage message
 *
 */
void displayUsage() {
	std::cout << "**********************************************************************"	<< std::endl;
	std::cout << "         TectroLabs - TL100 - Configuration utility Ver 2.1           "	    << std::endl;
	std::cout << "**********************************************************************"	<< std::endl;

	std::cout <<"NAME" << std::endl;
	std::cout <<"     configure - Enables a TL100 device to be used with Linux/OS X" << std::endl;
	std::cout <<"                 or Windows operating systems. Your RNG device was shipped" << std::endl;
	std::cout <<"                 with the default configuration setting for Windows." << std::endl;
	std::cout <<"                 You can use this utility to configure your RNG device for" << std::endl;
	std::cout <<"                 using with Linux and MAC OS X" << std::endl;
	std::cout <<"SYNOPSIS" << std::endl;
	std::cout <<"     configure [-slo, --set-linux-and-osx] [-sw, --set-windows]" << std::endl;
	std::cout <<"               [-ld, --list-devices] [-dn, --device-number]" << std::endl;
	std::cout << std::endl;
	std::cout <<"DESCRIPTION" << std::endl;
	std::cout <<"     The 'configure' utility will set up TL100 RNG devices to be used" << std::endl;
	std::cout <<"     with Linux, OS X or Windows operating systems. Once the device is" << std::endl;
	std::cout <<"     successfully configured, the device should be unplugged and plugged " << std::endl;
	std::cout <<"     back in for the configuration to take effect. This is a one time" << std::endl;
	std::cout <<"     procedure that will write configuration changes to the permanent" << std::endl;
	std::cout <<"     memory storage of the device." << std::endl;
	std::cout << std::endl;
	std::cout <<"OPTIONS" << std::endl;
	std::cout <<"     Operation modifiers:" << std::endl;
	std::cout << std::endl;
	std::cout <<"     -dn NUMBER, --device-number NUMBER" << std::endl;
	std::cout <<"           USB device NUMBER. Use option '-ld' to find the TL100 device number" << std::endl;
	std::cout  << std::endl;
	std::cout <<"     -slo, --set-linux-and-osx" << std::endl;
	std::cout <<"           This option will configure the TL100 device for using with" << std::endl;
	std::cout <<"           Linux or Mac OS X operating systems. Once the device is " << std::endl;
	std::cout <<"           successfully configured, the device should be unplugged " << std::endl;
	std::cout <<"           and plugged back in for the configuration to take effect" << std::endl;
	std::cout  << std::endl;
	std::cout <<"     -sw, --set-windows" << std::endl;
	std::cout <<"           This option will configure the TL100 device for using with" << std::endl;
	std::cout <<"           the Windows operating system. Once the device is successfully" << std::endl;
	std::cout <<"           configured, the device should be unplugged and plugged back in" << std::endl;
	std::cout <<"           for the configuration to take effect" << std::endl;
	std::cout  << std::endl;
	std::cout <<"     -ld, --list-devices" << std::endl;;
	std::cout <<"           list all available TL100 connected devices and configurations" << std::endl;
	std::cout << std::endl;
	std::cout << "EXAMPLES:" << std::endl;
	std::cout << "    To list all of the TL100 devices currently connected:" << std::endl;
	std::cout << "       sudo ./configure -ld" << std::endl;
	std::cout << std::endl;
	std::cout << "    To configure TL100 device number 0 to be used with Linux or Mac OS X:" << std::endl;
	std::cout << "    sudo ./configure -slo -dn 0" << std::endl;
	std::cout << std::endl;
	std::cout << "    To configure TL100 device number 0 to be used with Windows:" << std::endl;
	std::cout << "    sudo ./configure -sw -dn 0" << std::endl;
	std::cout << std::endl;
	std::cout << "    To configure TL100 device number 2 to be used with Linux or Mac OS X:" << std::endl;
	std::cout << "    sudo ./configure -sw -dn 2" << std::endl;
	std::cout << std::endl;
}


//
// Main entry
//
int main(int argc, char **argv) {
	int idx = 1;
	if (argc == 1) {
		displayUsage();
	} else {
		initialize();
		while( idx < argc) {
			if (strcmp("-ld", argv[idx]) == 0 || strcmp("--list-devices", argv[idx]) == 0 ) {
				cmdListDevices = true;
				idx++;
				continue;
			} else if (strcmp("-slo", argv[idx]) == 0 || strcmp("--set-linux-and-osx", argv[idx]) == 0 ) {
				cmdSetLinuxAndOSX = true;
				idx++;
				continue;
			} else if (strcmp("-sw", argv[idx]) == 0 || strcmp("--set-windows", argv[idx]) == 0 ) {
				cmdSetWindows = true;
				idx++;
				continue;
			} else if (strcmp("-dn", argv[idx]) == 0 || strcmp("--device-number", argv[idx]) == 0 ) {
				if (++idx >= argc) {
					std::cerr << "Device number missing" << std::endl;
					return -1;
				}
				deviceNum = atoi(argv[idx++]);
				if (deviceNum < 0 || deviceNum >= 127) {
					std::cerr << "Invalid device number: " << deviceNum << std::endl;
					return -1;
				}
			} else {
				idx++;
			}
		}
	}
	if (!validatePrameters()) {
		return -1;
	}

	processCommand();
}

