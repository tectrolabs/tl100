/*
 * MemoryBuffer.h
 * ver. 2.1
 *
 */

/*********************************************************************************************

Copyright (C) 2013-2015 TectroLabs, http://tectrolabs.com

THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

This class may only be used in conjunction with the TL100 device.

*********************************************************************************************/

#ifndef MEMBUFFER_H_
#define MEMBUFFER_H_

#include <stdint.h>

class MemoryBuffer {

	public:
		MemoryBuffer();
		virtual ~MemoryBuffer();
		int initialize(int bytes);
		uint8_t *getAddress();
		int getAllocatedSize();

	private:
		uint8_t *buff;
		int bytesAllocated;

};

#endif /* MEMBUFFER_H_ */
